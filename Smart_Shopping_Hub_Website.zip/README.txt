SMART SHOPPING HUB — STARTER WEBSITE

1. Open index.html in a browser to preview the website.
2. The product buttons are demo buttons; they do NOT contain affiliate links.
3. Only add genuine affiliate links after an eligible adult account is approved and the program terms allow your website as a traffic source.
4. Keep the affiliate disclosure visible and check current Flipkart terms before publishing.
5. To publish free, you can use a static hosting service such as GitHub Pages or Netlify, with a parent/guardian helping manage any required account.
